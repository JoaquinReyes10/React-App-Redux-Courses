var request = new XMLHttpRequest();

request.open("GET", "https://ghibliapi.herokuapp.com/films", true)
request.onload = function() {
  var respuesta = JSON.parse(this.response)
  if (respuesta.status >= 200 && respuesta.status < 400) {
    respuesta.forEach(function (objeto, indice){
      var contenedor = document.createElement("div");

      var titulo = document.createElement("div");
      titulo.innerHTML = objeto.title;
      contenedor.appendChild(titulo);
      var div_1 = document.createElement("div.pelicula__titulo");
      div_1.appendChild(contenedor);
      objeto.title.appendChild(div_1);
      var div_2 = document.createElement("pelicula__descripcion");
      div_2.appendChild(contenedor);
      objeto.title.appendChild(div_2);

      contenedor.appendChild("#root");
      app.appendChild(contenedor);
    })
  }
}
request.send()
  fetch("https://ghibliapi.herokuapp.com/films")
  .then(response => response.json())
  .then(json => document.getElementById("root").innerHTML=(json))
